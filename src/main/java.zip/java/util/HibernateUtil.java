package util;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;
import java.nio.file.InvalidPathException;
import java.nio.file.Path;
import java.util.LinkedList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AvailableSettings;
import org.hibernate.cfg.Configuration;

public class HibernateUtil {

	private static final String DB = "torneapp"; // ⚠️ pon el nombre REAL de tu BD
	private static final int PORT = 3306;
	private static final String USER = "root"; // ⚠️ tu usuario MySQL
	private static final String PASS = "170804"; // ⚠️ tu contraseña MySQL
	private static final String SUBPROTOCOL = "jdbc:mysql://";
	private static final String HOST = "localhost";
	private static final String PACK = "modelo"; // 🔥 MUY IMPORTANTE
	private static SessionFactory sessionFactory;

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	private static boolean estaPuertoOcupado(int puerto) {
		try (ServerSocket serverSocket = new ServerSocket(puerto)) {
			serverSocket.setReuseAddress(true);
			return false;
		} catch (IOException e) {
			return true;
		}
	}

	private static boolean estaMySQLFuncionando() {
		return estaPuertoOcupado(PORT);
	}

	public static void shutDown() {
		getSessionFactory().close();
	}

	public static Session getCurrentSession() {
		if (sessionFactory == null) {
			creaSessionFactory();
		}
		return sessionFactory.getCurrentSession();
	}

	private static void creaSessionFactory() {
		if (!estaMySQLFuncionando()) {
			System.err.println("MySQL no está funcionando");
		}

		try {
			Configuration config = new Configuration().configure("hibernate.cfg.xml");

			incluyePropiedades(config);
			incluyeClases(config);

			sessionFactory = config.buildSessionFactory();

		} catch (Throwable e) {
			throw new ExceptionInInitializerError(e);
		}
	}

	private static void incluyePropiedades(Configuration config) {
		String URL = String.format("%s%s:%d/%s", SUBPROTOCOL, HOST, PORT, DB);

		config.setProperty(AvailableSettings.URL, URL);
		config.setProperty(AvailableSettings.USER, USER);
		config.setProperty(AvailableSettings.PASS, PASS);
	}

	private static void incluyeClases(Configuration config) {
	    config.addAnnotatedClass(modelo.Usuario.class);
	    config.addAnnotatedClass(modelo.Federacion.class);
	    config.addAnnotatedClass(modelo.Club.class);
	    config.addAnnotatedClass(modelo.Entrenador.class);
	    config.addAnnotatedClass(modelo.Equipo.class);
	    config.addAnnotatedClass(modelo.Torneo.class);
	    config.addAnnotatedClass(modelo.Partido.class);
	    config.addAnnotatedClass(modelo.Participa.class);
	    config.addAnnotatedClass(modelo.ParticipaId.class);
	    config.addAnnotatedClass(modelo.Juega.class);
	    config.addAnnotatedClass(modelo.JuegaId.class);
	}
	private static List<Class<?>> entidades() {
		List<Class<?>> lista = new LinkedList<>();
		Path path = null;

		try {
			path = Path.of(System.getProperty("user.dir"), "src", "main", "java", PACK);
		} catch (InvalidPathException e) {
			e.printStackTrace();
		}

		if (path == null)
			return lista;

		File f = path.toFile();
		for (File file : f.listFiles()) {
			String nombre = file.getName();
			if (nombre.endsWith(".java")) {
				Class<?> c = creaClass(nombre);
				if (c != null)
					lista.add(c);
			}
		}
		return lista;
	}

	private static Class<?> creaClass(String nombre) {
		String nombreTruncado = nombre.substring(0, nombre.length() - 5);
		String nombreCompleto = PACK + "." + nombreTruncado;
		try {
			return Class.forName(nombreCompleto);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return null;
	}
}

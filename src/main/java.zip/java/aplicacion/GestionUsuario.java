package aplicacion;

import modelo.Usuario;
import modelo.RolUsuario;
import servicio.ServicioUsuario;

public class GestionUsuario {

    private ServicioUsuario servicioUsuario;

    public GestionUsuario() {
        this.servicioUsuario = new ServicioUsuario();
    }

    public Usuario registrarUsuario(String nombre, String email, String password, RolUsuario rol) {
        Usuario nuevoUsuario = new Usuario(nombre, email, password, rol);
        servicioUsuario.crearUsuario(nuevoUsuario);
        return nuevoUsuario; // Importante devolverlo para el Main
    }
}
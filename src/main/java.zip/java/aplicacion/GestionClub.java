package aplicacion;

import modelo.Club;
import modelo.Equipo;
import modelo.Torneo;
import servicio.ServicioEquipo;
import servicio.ServicioClub;

public class GestionClub {
    private ServicioEquipo servicioEquipo;
    private ServicioClub servicioClub;

    public GestionClub() {
        this.servicioEquipo = new ServicioEquipo();
        this.servicioClub = new ServicioClub();
    }

    public void crearClub(Club club) {
        servicioClub.crearClub(club);
    }

    // El Club crea el equipo y genera el código automáticamente
    public Equipo darAltaEquipo(String nombre, Club club) {
        Equipo nuevoEquipo = new Equipo(nombre, club);
        servicioEquipo.crearEquipo(nuevoEquipo);
        return nuevoEquipo;
    }

    public void inscribirEnTorneo(Equipo e, Torneo t) {
        if ("APROBADO".equals(t.getEstado())) {
            servicioClub.inscribirEquipo(e, t);
        } else {
            System.out.println("No se puede inscribir: Torneo no validado por Federación.");
        }
    }
}
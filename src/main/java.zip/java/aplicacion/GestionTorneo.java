package aplicacion;

import modelo.Club;
import modelo.Torneo;
import servicio.ServicioTorneo;

import java.util.List;

public class GestionTorneo {

    private ServicioTorneo servicioTorneo;

    public GestionTorneo() {
        this.servicioTorneo = new ServicioTorneo();
    }

    public void crearTorneo(String nombre, String localizacion,
                            String fechaInicio, String fechaFin,
                            String categoria, String normas,
                            Club club) {

       Torneo torneo = new Torneo(nombre, localizacion, fechaInicio, fechaFin, categoria, normas, club);
        servicioTorneo.crearTorneo(torneo);
        
    }

    public List<Torneo> listarTorneos() {
        return servicioTorneo.listarTorneos();
    }

    public Torneo obtenerTorneo(int idTorneo) {
        return servicioTorneo.buscarTorneoPorId(idTorneo);
    }
}
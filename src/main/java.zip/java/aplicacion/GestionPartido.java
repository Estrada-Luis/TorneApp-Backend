package aplicacion;

import modelo.Partido;
import modelo.Torneo;
import servicio.ServicioPartido;

import java.util.List;

public class GestionPartido {

    private ServicioPartido servicioPartido;

    public GestionPartido() {
        this.servicioPartido = new ServicioPartido();
    }

    public void crearPartido(String fecha, String hora, String resultado, Torneo torneo) {
        Partido partido = new Partido(fecha, hora, resultado, torneo);
        servicioPartido.crearPartido(partido);
    }

    public List<Partido> listarPartidosPorTorneo(int idTorneo) {
        return servicioPartido.listarPartidosPorTorneo(idTorneo);
    }

    public Partido obtenerPartido(int idPartido) {
        return servicioPartido.obtenerPartido(idPartido);
    }
}
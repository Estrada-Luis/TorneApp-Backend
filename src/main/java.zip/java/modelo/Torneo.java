package modelo;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "torneo")
public class Torneo implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_torneo;

    private String nombre;
    private String localizacion;
    private String fechaInicio;
    private String fechaFin;
    private String categoria;
    private String normas;
    private String estado = "PENDIENTE"; // Importante para la descripción que diste

    @ManyToOne
    @JoinColumn(name = "id_club", nullable = false)
    private Club clubOrganizador;

    public Torneo() {}

    public Torneo(String nombre, String localizacion, String fechaInicio, String fechaFin, String categoria, String normas, Club club) {
        this.nombre = nombre;
        this.localizacion = localizacion;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.categoria = categoria;
        this.normas = normas;
        this.clubOrganizador = club;
    }

    // Getters y Setters
    public int getIdTorneo() { return id_torneo; }
    public String getNombre() { return nombre; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public Club getClubOrganizador() { return clubOrganizador; }
    
    @Override
    public String toString() {
        return "Torneo [Nombre=" + nombre + ", Estado=" + estado + ", Categoria=" + categoria + "]";
    }
}

package modelo;

import java.util.List;

import javax.persistence.*;

@Entity
@Table(name = "partido")
public class Partido {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_partido")
    private int idPartido;

    @Column
    private String fecha;

    @Column
    private String hora;

    @Column
    private String resultado;

    @ManyToOne
    @JoinColumn(name = "id_torneo", nullable = false)
    private Torneo torneo;

    @OneToMany(mappedBy = "partido", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<Juega> juegos;

    public Partido() {}

    public Partido(String fecha, String hora, String resultado, Torneo torneo) {
		this.fecha = fecha;
		this.hora = hora;
		this.resultado = resultado;
		this.torneo = torneo;
	}
    // Getters y setters
    public int getIdPartido() {
        return idPartido;
    }

    public void setIdPartido(int idPartido) {
        this.idPartido = idPartido;
    }

    public Torneo getTorneo() {
        return torneo;
    }

    public void setTorneo(Torneo torneo) {
        this.torneo = torneo;
    }
    
    public String getFecha() {
	return fecha;
	}
    	public void setFecha(String fecha) {
    	this.fecha = fecha;
    	}
    	
    	public String getHora() {
    	return hora;
    	}
    	public void setHora(String hora) {
		this.hora = hora;
		}
    	
		public String getResultado() {
		return resultado;
		}
		public void setResultado(String resultado) {
		this.resultado = resultado;
		}
		
		

    @Override
    public String toString() {
        return "Partido{" +
                "fecha='" + fecha + '\'' +
                ", hora='" + hora + '\'' +
                ", resultado='" + resultado + '\'' +
                ", torneo=" + torneo.getNombre() +
                '}';
    }
}
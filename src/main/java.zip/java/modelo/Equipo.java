package modelo;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "equipo")
public class Equipo implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_equipo;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(unique = true, length = 4)
    private String codigoVinculacion;

    @ManyToOne
    @JoinColumn(name = "id_club", nullable = false)
    private Club club;

    public Equipo() {}

    public Equipo(String nombre, Club club) {
        this.nombre = nombre;
        this.club = club;
    }

    // --- GETTERS Y SETTERS ---

    public int getIdEquipo() { return id_equipo; }
    public void setIdEquipo(int id_equipo) { this.id_equipo = id_equipo; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    // ESTE ES EL MÉTODO QUE TE FALTA Y CAUSA EL ERROR
    public void setCodigoVinculacion(String codigoVinculacion) {
        this.codigoVinculacion = codigoVinculacion;
    }

    public String getCodigoVinculacion() {
        return codigoVinculacion;
    }

    public Club getClub() { return club; }
    public void setClub(Club club) { this.club = club; }

    @Override
    public String toString() {
        return "Equipo [Nombre=" + nombre + ", Código=" + codigoVinculacion + "]";
    }
}
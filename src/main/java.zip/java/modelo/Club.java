package modelo;

import java.io.Serializable;
import javax.persistence.*;

@Entity
@Table(name = "club")
public class Club implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_club;

    @Column(unique = true, nullable = false)
    private String cif;
    private String nombre;
    private String direccion;
    private String telefono;
    private String correo;
    private boolean validado = false; // Importante para el perfil Federación

    @ManyToOne
    @JoinColumn(name = "id_federacion", nullable = false)
    private Federacion federacion;

    public Club() {}

    public Club(String nombre, String cif, String direccion, String telefono, String correo, boolean validado, Federacion federacion) {
        this.nombre = nombre;
        this.cif = cif;
        this.direccion = direccion;
        this.telefono = telefono;
        this.correo = correo;
        this.validado = validado;
        this.federacion = federacion;
    }

    // Getters y Setters
    public int getIdClub() { return id_club; }
    public String getNombre() { return nombre; }
    public String getCif() { return cif; }
    public boolean isValidado() { return validado; }
    public void setValidado(boolean validado) { this.validado = validado; }
    public Federacion getFederacion() { return federacion; }
}

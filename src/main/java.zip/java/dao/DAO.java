package dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Session;
import util.HibernateUtil;

public class DAO<T> {

	private Class<T> clase;

	public DAO(Class<T> clase) {
		this.clase = clase;
	}

	public void create(T t) {
		Session session = HibernateUtil.getCurrentSession();
		session.beginTransaction();
		session.save(t);
		session.getTransaction().commit();
	}

	public T read(Serializable id) {
		Session session = HibernateUtil.getCurrentSession();
		session.beginTransaction();
		T t = session.get(clase, id);
		session.getTransaction().commit();
		return t;
	}

	public void update(T t) {
		Session session = HibernateUtil.getCurrentSession();
		session.beginTransaction();
		session.update(t);
		session.getTransaction().commit();
	}

	public void delete(T t) {
		Session session = HibernateUtil.getCurrentSession();
		session.beginTransaction();
		session.delete(t);
		session.getTransaction().commit();
	}
	
	public List<T> readAll() {
        Session session = HibernateUtil.getCurrentSession();
        session.beginTransaction();
        List<T> lista = session
                .createQuery("from " + clase.getSimpleName(), clase)
                .list();
        session.getTransaction().commit();
        return lista;
    }
	
}

package dao;

import modelo.Usuario;
import util.HibernateUtil;

import org.hibernate.Session;

public class UsuarioDAO extends DAO<Usuario> {

    public UsuarioDAO() {
        super(Usuario.class);
    }

    public void create(Usuario usuario) {
        Session session = HibernateUtil.getCurrentSession();
        session.beginTransaction();
        session.save(usuario);
        session.getTransaction().commit();
    }

    public Usuario read(int idUsuario) {
        Session session = HibernateUtil.getCurrentSession();
        session.beginTransaction();
        Usuario usuario = session.get(Usuario.class, idUsuario);
        session.getTransaction().commit();
        return usuario;
    }
    
    public Usuario findByEmail(String email) {
		Session session = HibernateUtil.getCurrentSession();
		session.beginTransaction();
		Usuario usuario = session.createQuery("FROM Usuario WHERE email = :email", Usuario.class)
								 .setParameter("email", email)
								 .uniqueResult();
		session.getTransaction().commit();
		return usuario;
	}
}

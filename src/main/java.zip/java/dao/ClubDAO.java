package dao;

import modelo.Club;
import util.HibernateUtil;

import org.hibernate.Session;

public class ClubDAO extends DAO<Club> {

    public ClubDAO() {
        super(Club.class);
    }

    public void create(Club club) {
        Session session = HibernateUtil.getCurrentSession();
        session.beginTransaction();
        session.save(club);
        session.getTransaction().commit();
    }

    public Club read(int idClub) {
        Session session = HibernateUtil.getCurrentSession();
        session.beginTransaction();
        Club club = session.get(Club.class, idClub);
        session.getTransaction().commit();
        return club;
    }
}
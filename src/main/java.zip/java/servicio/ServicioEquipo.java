package servicio;

import dao.EquipoDAO;
import modelo.Equipo;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class ServicioEquipo {

    private EquipoDAO equipoDAO;

    public ServicioEquipo() {
        this.equipoDAO = new EquipoDAO();
    }

    public void crearEquipo(Equipo equipo) {
        // Generación del código alfanumérico de 4 caracteres (ej: CP3A)
        String caracteres = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder sb = new StringBuilder();
        Random rnd = new Random();
        while (sb.length() < 4) {
            sb.append(caracteres.charAt(rnd.nextInt(caracteres.length())));
        }
        equipo.setCodigoVinculacion(sb.toString());
        
        equipoDAO.create(equipo);
    }

    public List<Equipo> listarEquipos() {
        return equipoDAO.readAll();
    }

    // CORRECCIÓN: Filtrado manual porque el DAO no tiene findByClub
    public List<Equipo> listarEquiposPorClub(int idClub) {
        return equipoDAO.readAll().stream()
                .filter(e -> e.getClub() != null && e.getClub().getIdClub() == idClub)
                .collect(Collectors.toList());
    }

    public Equipo obtenerEquipo(int idEquipo) {
        return equipoDAO.read(idEquipo);
    }

    public void eliminarEquipo(int idEquipo) {
        Equipo equipo = equipoDAO.read(idEquipo);
        if (equipo != null) {
            equipoDAO.delete(equipo);
        }
    }

    public void actualizarEquipo(Equipo equipo) {
        equipoDAO.update(equipo);
    }
}
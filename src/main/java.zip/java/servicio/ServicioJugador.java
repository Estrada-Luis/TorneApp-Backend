package servicio;

import dao.JugadorDAO;
import modelo.Jugador;
import modelo.Equipo;
import java.util.List;
import java.util.stream.Collectors;

public class ServicioJugador {

    private JugadorDAO jugadorDAO;

    public ServicioJugador() {
        this.jugadorDAO = new JugadorDAO();
    }

    public void registrarJugador(String nombre, int edad, Equipo equipo) {
        Jugador nuevoJugador = new Jugador(nombre, edad, equipo);
        jugadorDAO.create(nuevoJugador);
    }

    public List<Jugador> listarJugadoresPorEquipo(int idEquipo) {
        // Filtrado funcional por equipo
        return jugadorDAO.readAll().stream()
                .filter(j -> j.getEquipo().getIdEquipo() == idEquipo)
                .collect(Collectors.toList());
    }
    public void eliminarJugador(int id) {
        // Primero recuperamos el objeto de la BD
        Jugador j = jugadorDAO.read(id);
        if (j != null) {
            jugadorDAO.delete(j);
            System.out.println("[SERVICIO] Jugador con ID " + id + " eliminado.");
        } else {
            System.out.println("[SERVICIO] Error: No se encontró el jugador.");
        }
    }
}
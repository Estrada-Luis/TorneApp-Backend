package servicio;

import modelo.Usuario;
import java.util.List;

import dao.DAO;

public class ServicioUsuario {

    private DAO<Usuario> usuarioDAO;

    public ServicioUsuario() {
        this.usuarioDAO = new DAO<>(Usuario.class);
    }

    public void crearUsuario(Usuario usuario) {
        if (usuario != null) {
            usuarioDAO.create(usuario);
            System.out.println("[SERVICIO] Usuario guardado: " + usuario.getEmail());
        }
    }

    public List<Usuario> listarUsuarios() {
        return usuarioDAO.readAll();
    }
}

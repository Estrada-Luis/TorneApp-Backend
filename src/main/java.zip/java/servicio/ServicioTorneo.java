package servicio;

import dao.TorneoDAO;
import modelo.Torneo;

import java.util.List;

public class ServicioTorneo {

    private TorneoDAO torneoDAO;

    public ServicioTorneo() {
        this.torneoDAO = new TorneoDAO();
    }

    // Crear torneo
    public Torneo crearTorneo(Torneo torneo) {
        torneoDAO.create(torneo);
        return torneo;
    }

    // Buscar torneo por ID
    public Torneo buscarTorneoPorId(int id) {
        return torneoDAO.read(id);
    }

    // Listar todos los torneos
    public List<Torneo> listarTorneos() {
        return torneoDAO.readAll();
    }

    // Eliminar torneo
    public void eliminarTorneo(Torneo torneo) {
        torneoDAO.delete(torneo);
    }

   
}
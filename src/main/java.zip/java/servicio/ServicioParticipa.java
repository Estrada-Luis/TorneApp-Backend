package servicio;

import dao.ParticipaDAO;
import modelo.Equipo;
import modelo.Participa;
import modelo.ParticipaId;
import modelo.Torneo;

import java.util.ArrayList;
import java.util.List;

public class ServicioParticipa {

    private ParticipaDAO participaDAO;

    public ServicioParticipa() {
        this.participaDAO = new ParticipaDAO();
    }

    // ===============================
    // INSCRIBIR EQUIPO EN TORNEO
    // ===============================
    public void inscribirEquipo(Equipo equipo, Torneo torneo) {

        ParticipaId id = new ParticipaId(
                equipo.getIdEquipo(),
                torneo.getIdTorneo()
        );

        Participa participa = new Participa();
        participa.setId(id);
        participa.setEquipo(equipo);
        participa.setTorneo(torneo);

        participaDAO.create(participa);
    }

    // ===============================
    // OBTENER EQUIPOS DE UN TORNEO
    // ===============================
    public List<Equipo> obtenerEquiposPorTorneo(int idTorneo) {

        List<Participa> inscripciones = participaDAO.readAll();
        List<Equipo> equipos = new ArrayList<>();

        for (Participa p : inscripciones) {
            if (p.getTorneo().getIdTorneo() == idTorneo) {
                equipos.add(p.getEquipo());
            }
        }
        return equipos;
    }

    // ===============================
    // ELIMINAR INSCRIPCIÓN
    // ===============================
    public void eliminar(Participa participa) {
        participaDAO.delete(participa);
    }
}
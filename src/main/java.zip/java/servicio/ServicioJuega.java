package servicio;

import dao.JuegaDAO;
import modelo.Equipo;
import modelo.Juega;
import modelo.JuegaId;
import modelo.Partido;

import java.util.ArrayList;
import java.util.List;

public class ServicioJuega {

    private JuegaDAO juegaDAO;

    public ServicioJuega() {
        this.juegaDAO = new JuegaDAO();
    }

    // ===============================
    // AÑADIR EQUIPO A UN PARTIDO
    // ===============================
    public void añadirEquipoAPartido(Equipo equipo, Partido partido) {

        JuegaId id = new JuegaId(
                equipo.getIdEquipo(),
                partido.getIdPartido()
        );

        Juega juega = new Juega();
        juega.setId(id);
        juega.setEquipo(equipo);
        juega.setPartido(partido);

        juegaDAO.create(juega);
    }

    // ===============================
    // OBTENER EQUIPOS DE UN PARTIDO
    // ===============================
    public List<Equipo> obtenerEquiposPorPartido(int idPartido) {

        List<Equipo> equipos = new ArrayList<>();

        for (Juega j : juegaDAO.readAll()) {
            if (j.getPartido().getIdPartido() == idPartido) {
                equipos.add(j.getEquipo());
            }
        }
        return equipos;
    }

    // ===============================
    // ELIMINAR RELACIÓN
    // ===============================
    public void eliminar(Juega juega) {
        juegaDAO.delete(juega);
    }
}
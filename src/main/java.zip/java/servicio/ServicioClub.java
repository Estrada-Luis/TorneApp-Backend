package servicio;

import dao.DAO;
import modelo.Club;
import modelo.Equipo;
import modelo.Torneo;

public class ServicioClub {
    private DAO<Club> clubDAO = new DAO<>(Club.class);

    public void crearClub(Club club) {
        clubDAO.create(club);
    }

    public void inscribirEquipo(Equipo e, Torneo t) {
        // Aquí iría la lógica para guardar en la tabla 'participa'
        System.out.println("Equipo " + e.getNombre() + " inscrito en " + t.getNombre());
    }
}

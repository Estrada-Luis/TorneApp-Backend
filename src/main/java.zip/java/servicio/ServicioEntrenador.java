package servicio;

import dao.DAO;

import modelo.Entrenador;
import modelo.Equipo;
import modelo.Usuario;

public class ServicioEntrenador {

    private DAO<Entrenador> entrenadorDAO;
    private DAO<Equipo> equipoDAO;

    public ServicioEntrenador() {
        this.entrenadorDAO = new DAO<>(Entrenador.class);
        this.equipoDAO = new DAO<>(Equipo.class);
    }

    public Entrenador registrarEntrenadorConCodigo(Usuario usuario, String codigo, String telefono) {
        // Buscamos equipo por token
        Equipo equipo = equipoDAO.readAll().stream()
                .filter(e -> e.getCodigoVinculacion() != null && e.getCodigoVinculacion().equals(codigo))
                .findFirst()
                .orElse(null);

        if (equipo == null) return null;

        Entrenador e = new Entrenador(telefono, equipo, usuario);
        entrenadorDAO.create(e);
        return e;
    }

    public void eliminarEntrenador(int id) {
        Entrenador e = entrenadorDAO.read(id);
        if (e != null) {
            entrenadorDAO.delete(e);
        }
    }
}
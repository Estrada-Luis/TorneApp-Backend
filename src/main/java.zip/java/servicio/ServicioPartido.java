package servicio;

import dao.PartidoDAO;
import modelo.Partido;

import java.util.ArrayList;
import java.util.List;

public class ServicioPartido {

    private PartidoDAO partidoDAO;

    public ServicioPartido() {
        this.partidoDAO = new PartidoDAO();
    }

    public void crearPartido(Partido partido) {
        partidoDAO.create(partido);
    }

    public Partido obtenerPartido(int id) {
        return partidoDAO.read(id);
    }

    public List<Partido> listarPartidos() {
        return partidoDAO.readAll();
    }

    public List<Partido> listarPartidosPorTorneo(int idTorneo) {
        List<Partido> partidos = new ArrayList<>();

        for (Partido p : partidoDAO.readAll()) {
            if (p.getTorneo().getIdTorneo() == idTorneo) {
                partidos.add(p);
            }
        }
        return partidos;
    }

    public void actualizarPartido(Partido partido) {
        partidoDAO.update(partido);
    }

    public void eliminarPartido(Partido partido) {
        partidoDAO.delete(partido);
    }
}